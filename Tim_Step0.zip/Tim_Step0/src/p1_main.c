//This file contains relevant pin and other settings 
#include <LPC17xx.h>

//This file is for printf and other IO functions
#include "stdio.h"
#include "stdbool.h"
#include "stdlib.h"
//this file sets up the UART
#include "uart.h"

unsigned int map(int ordinal)
{
	int map[] = {28, 29, 31, 2, 3, 4, 5, 6};
	return map[ordinal];
}

void turnOnLEDS(unsigned int num)
{
	for(int bit = 0; bit < 8; bit++)
	{
		unsigned int mask = 1U<<bit;
		unsigned int flag = mask & num;
		if(flag)
		{
			if(bit < 3)
			{
				LPC_GPIO1->FIOSET |= 1U << map(bit);
			}
			else
			{
				LPC_GPIO2->FIOSET |= 1U << map(bit);
			}
		}
	}	
}

void operateJoyStick()
{
	while(1){
		unsigned int pin1 = LPC_GPIO1->FIOPIN & (1U<<23);
		if(!pin1)
		{
			printf("UP");
			if(LPC_GPIO1->FIOPIN & (1U<<23))
			{
				pin1 = 1;
			}
		}
		
		unsigned int pin2 = LPC_GPIO1->FIOPIN & (1U<<25);
		if(!pin2)
		{
			printf("DOWN");
			if(LPC_GPIO1->FIOPIN & (1U<<25))
			{
				pin2 = 1;
			}
		}
		
		unsigned int pin3 = LPC_GPIO1->FIOPIN & (1U<<26);
		if(!pin3)
		{
			printf("LEFT");
			if(LPC_GPIO1->FIOPIN & (1U<<26))
			{
				pin3 = 1;
			}
		}
		
		unsigned int pin4 = LPC_GPIO1->FIOPIN & (1U<<24);
		if(!pin4)
		{
			printf("RIGHT");
			if(LPC_GPIO1->FIOPIN & (1U<<24))
			{
				pin4 = 1;
			}
		}
		
		unsigned int pin5 = LPC_GPIO1->FIOPIN & (1U<<20);
		if(!pin5)
		{
			printf("JOYSTICK_PUSHED");
			if(LPC_GPIO1->FIOPIN & (1U<<20))
			{
				pin5 = 1;
			}
		}
		
		unsigned int pin6 = LPC_GPIO2->FIOPIN & (1U<<10);
		if(!pin6)
		{
			printf("PUSHBUTTON_PUSHED");
			if(LPC_GPIO2->FIOPIN & (1U<<10))
			{
				pin6 = 1;
			}
		}
	}
}

void allocateArr()
{
	bool go = 1;
	int size = 0;
	while(LPC_GPIO2->FIOPIN & (1U<<10))
	{
		unsigned int pinUp = LPC_GPIO1->FIOPIN & (1U<<23);
		if(!pinUp)
		{
			size++;
			printf("size: %i\n", size);
		}
		
		unsigned int pinDown = LPC_GPIO1->FIOPIN & (1U<<25);
		if(!pinDown)
		{
			size--;
			printf("size: %i\n", size);
		}
	}
	if(size>0)
	{
		int *arr = malloc(size*sizeof(int));
		for(int i = 0; i < size; i++)
		{
			arr[i] = i+1;
			printf("%i, ",arr[i]);
		}
		free(arr);
	}
}

void size()
{
	printf("size of int is %i bytes\n", sizeof(char));
	printf("size of int is %i bytes\n", sizeof(short));
	printf("size of int is %i bytes\n", sizeof(int));
	printf("size of int is %i bytes\n", sizeof(long int));
	printf("size of int is %i bytes\n", sizeof(long long int));
}

void ex3()
{
	char *charPtr = malloc(sizeof(char));
	short *shortPtr = malloc(sizeof(short));
	int *intPtr = malloc(sizeof(int));
	long int *lintPtr = malloc(sizeof(long int));
	long long int *llintPtr = malloc(sizeof(long long int));
	
	printf("address: %i\n", (uint32_t)charPtr);
	printf("address: %i\n", (uint32_t)shortPtr);
	printf("address: %i\n", (uint32_t)intPtr);
	printf("address: %i\n", (uint32_t)lintPtr);
	printf("address: %i\n\n", (uint32_t)llintPtr);
	
	charPtr++;
	shortPtr++;
	intPtr++;
	lintPtr++;
	llintPtr++;
	
	printf("address: %i\n", (uint32_t)charPtr);
	printf("address: %i\n", (uint32_t)shortPtr);
	printf("address: %i\n", (uint32_t)intPtr);
	printf("address: %i\n", (uint32_t)lintPtr);
	printf("address: %i\n\n", (uint32_t)llintPtr);
	
}

int f1(int n1)
{
	return n1*n1;
}
int f2(int n2)
{
	return n2*n2*n2;
}
int f3(int n3)
{
	return n3*2;
}

void ex4()
{
	int (**arr)(int) = malloc(3*sizeof(uint32_t));
	int (*ptr1)(int) = &f1;
	int (*ptr2)(int) = &f2;
	int (*ptr3)(int) = &f3;
	arr[0] = ptr1;
	arr[1] = ptr2;
	arr[2] = ptr3;
	for(int i = 0; i < 3; i++)
	{
		printf("ans: %i\n",arr[i](3));
	}
	free(arr);
}

void ex5(void* ptr)
{
	int *ptr2 = (int*)ptr;
	printf("num: %i\n",*ptr2);
	if(ptr2)
	{
		(*ptr2) += 5;
	}
	printf("num: %i",*ptr2);
}

//This is C. The expected function heading is int main(void)
int main( void ) 
{
	//Always call this function at the start. It sets up various peripherals, the clock etc. If you don't call this
	//you may see some weird behaviour
	SystemInit();

	LPC_GPIO1->FIODIR |= 1<<28;
	LPC_GPIO1->FIODIR |= 1<<29;
	LPC_GPIO1->FIODIR |= 1<<31;
	LPC_GPIO2->FIODIR |= 1<<2;
	LPC_GPIO2->FIODIR |= 1<<3;
	LPC_GPIO2->FIODIR |= 1<<4;
	LPC_GPIO2->FIODIR |= 1<<5;
	LPC_GPIO2->FIODIR |= 1<<6;
	
	LPC_GPIO1->FIOCLR |= 1<<28;
	LPC_GPIO1->FIOCLR |= 1<<29;
	LPC_GPIO1->FIOCLR |= 1<<31;
	LPC_GPIO2->FIOCLR |= 1<<2;
	LPC_GPIO2->FIOCLR |= 1<<3;
	LPC_GPIO2->FIOCLR |= 1<<4;
	LPC_GPIO2->FIOCLR |= 1<<5;
	LPC_GPIO2->FIOCLR |= 1<<6;
	
	//turnOnLEDS(5);
	//operateJoyStick();
	//allocateArr();
	//size();
	//ex3();
	void *ptr = malloc(sizeof(int));
	ex5(ptr);
	//Your code should always terminate in an endless loop if it is done. If you don't
	//the processor will enter a hardfault and will be weird
	while(1);
}
